--Execute the below script with DBA previlege

--Create the schema and give necessary previleges to work
create user mcb identified by mcb123;
grant create session,resource to mcb;
grant UNLIMITED TABLESPACE TO mcb;