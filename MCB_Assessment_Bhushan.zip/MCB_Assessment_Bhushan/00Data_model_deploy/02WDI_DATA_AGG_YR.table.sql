SET SERVEROUTPUT ON
set heading off
set echo off
spool deploy_framework_upgrade.log append;
SELECT 'WDI_DATA_AGG_YR.table.sql
----------------------------
' || SYSTIMESTAMP
FROM dual;

/*drop if exists*/
DECLARE
  v_count INTEGER := 0;
BEGIN
  FOR rec IN (SELECT object_name, object_type
              FROM user_objects
              WHERE object_name IN
              (
                'WDI_DATA_AGG_YR_AGG_YR'
              )
             )
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP ' || rec.object_type || ' ' || rec.object_name;
      DBMS_OUTPUT.PUT_LINE('Dropped object ' || rec.object_name);
    EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Failed to drop object ' || rec.object_name || ' - ' || SQLERRM);
    END;
  END LOOP;

END;  
/



/*Year wise aggregated data*/
Create table mcb.WDI_DATA_AGG_YR_AGG_YR (				
COUNTRY_NAME VARCHAR2(200),
    COUNTRY_CODE VARCHAR2(3),
    INDICATOR_NAME VARCHAR2(200),
    INDICATOR_CODE VARCHAR2(50),
	YEAR number,
	YEAR_DATA number
);
	 

SELECT 'WDI_DATA_AGG_YR.table.sql **End**
----------------------------
' || SYSTIMESTAMP
FROM dual;
spool off;