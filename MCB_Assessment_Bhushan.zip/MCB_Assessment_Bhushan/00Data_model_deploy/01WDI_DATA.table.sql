SET SERVEROUTPUT ON
set heading off
set echo off
spool deploy_framework_upgrade.log append;
SELECT 'WDI_DATA.table.sql
----------------------------
' || SYSTIMESTAMP
FROM dual;

/*drop if exists*/
DECLARE
  v_count INTEGER := 0;
BEGIN
  FOR rec IN (SELECT object_name, object_type
              FROM user_objects
              WHERE object_name IN
              (
                'WDI_DATA'
              )
             )
  LOOP
    BEGIN
      EXECUTE IMMEDIATE 'DROP ' || rec.object_type || ' ' || rec.object_name;
      DBMS_OUTPUT.PUT_LINE('Dropped object ' || rec.object_name);
    EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('Failed to drop object ' || rec.object_name || ' - ' || SQLERRM);
    END;
  END LOOP;

END;  
/
  
Create table mcb.WDI_DATA (				
	Country_Name		varchar2(200)	,
	Country_Code		varchar2(3)	,
	Indicator_Name		varchar2(200)	,
	Indicator_Code		varchar2(50)	,
	"1960"		number(4)	,
	"1961"		number(4)	,
	"1962"		number(4)	,
	"1963"		number(4)	,
	"1964"		number(4)	,
	"1965"		number(4)	,
	"1966"		number(4)	,
	"1967"		number(4)	,
	"1968"		number(4)	,
	"1969"		number(4)	,
	"1970"		number(4)	,
	"1971"		number(4)	,
	"1972"		number(4)	,
	"1973"		number(4)	,
	"1974"		number(4)	,
	"1975"		number(4)	,
	"1976"		number(4)	,
	"1977"		number(4)	,
	"1978"		number(4)	,
	"1979"		number(4)	,
	"1980"		number(4)	,
	"1981"		number(4)	,
	"1982"		number(4)	,
	"1983"		number(4)	,
	"1984"		number(4)	,
	"1985"		number(4)	,
	"1986"		number(4)	,
	"1987"		number(4)	,
	"1988"		number(4)	,
	"1989"		number(4)	,
	"1990"		number(4)	,
	"1991"		number(4)	,
	"1992"		number(4)	,
	"1993"		number(4)	,
	"1994"		number(4)	,
	"1995"		number(4)	,
	"1996"		number(4)	,
	"1997"		number(4)	,
	"1998"		number(4)	,
	"1999"		number(4)	,
	"2000"		number(4)	,
	"2001"		number(4)	,
	"2002"		number(4)	,
	"2003"		number(4)	,
	"2004"		number(4)	,
	"2005"		number(4)	,
	"2006"		number(4)	,
	"2007"		number(4)	,
	"2008"		number(4)	,
	"2009"		number(4)	,
	"2010"		number(4)	,
	"2011"		number(4)	,
	"2012"		number(4)	,
	"2013"		number(4)	,
	"2014"		number(4)	,
	"2015"		number(4)	,
	"2016"		number(4)	,
	"2017"		number(4)	,
	"2018"		number(4)	,
	"2019"		number(4)	,
	"2020"		number(4)	,
	"2021"		number(4) ,		
	 CONSTRAINT "WDI_DATA_PK" PRIMARY KEY (Country_Code,Indicator_Code)
);
	 

SELECT 'WDI_DATA.table.sql **End**
----------------------------
' || SYSTIMESTAMP
FROM dual;
spool off;