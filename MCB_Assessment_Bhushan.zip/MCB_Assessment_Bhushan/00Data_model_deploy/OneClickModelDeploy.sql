@00PreSetupDeploy.sql
@01WDI_DATA.table.sql
@02WDI_DATA_AGG_YR.table.sql