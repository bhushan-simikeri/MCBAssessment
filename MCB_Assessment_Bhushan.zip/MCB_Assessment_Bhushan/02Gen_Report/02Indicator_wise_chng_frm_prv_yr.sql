/*
Date of Creation: 20.07.2022
report Name  		: Indicator_wise_chng_frm_prv_yr
purpose		    : Indicator_wise_chng_frm_prv_yr
Owner           : bhushan simikeri
Email           : bhushan.simikeri@oracle.com

*/

SET SERVEROUTPUT ON
set heading off
set echo off
SET LINESIZE 32767
SET TRIMSPOOL ON -- otherwise every line in the spoolfile is filled up with blanks until the linesize is reached.
SET TRIMOUT ON --otherwise every line in the output is filled up with blanks until the linesize is reached.
spool Indicator_wise_chng_frm_prv_yr.csv append;

SELECT 'Indicator_wise_chng_frm_prv_yr.csv
----------------------------
' || SYSTIMESTAMP
FROM dual;

select 'COUNTRY_NAME,INDICATOR_NAME,curr_year, curr_yr_data , CHG_FRM_PRV_YR ' from dual;
select COUNTRY_NAME||','||INDICATOR_NAME||','||curr_year||','|| curr_yr_data ||','|| CHG_FRM_PRV_YR 
from (
SELECT COUNTRY_NAME,REPLACE(INDICATOR_NAME,',','-') INDICATOR_NAME, YEAR as curr_year, nvl(year_data,0) as curr_yr_data,
nvl(year_data,0) - LAG(nvl(year_data,0),1) OVER (partition by year order by year) CHG_FRM_PRV_YR
from WDI_DATA_AGG_YR_AGG_YR 
where indicator_name in (
'Total fisheries production (metric tons)',
'Agricultural land (sq. km)',
'Time required to start a business (days)',
'New businesses registered (number)',
'Employment in agriculture (% of total employment) (modeled ILO estimate)',
'Self-employed, total (% of total employment) (modeled ILO estimate)',
'Corruption Perception Index') and year ='2019' -- Current year considered for calculation
order by country_code, year desc) ;





 spool off;
