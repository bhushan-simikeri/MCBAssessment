/*
Date of Creation: 20.07.2022
report Name  		: Indicator_wise_comp_report
purpose		    : Indicator_wise_comp_report
Owner           : bhushan simikeri
Email           : bhushan.simikeri@oracle.com

*/

SET SERVEROUTPUT ON
set heading off
set echo off
SET LINESIZE 32767
SET TRIMSPOOL ON -- otherwise every line in the spoolfile is filled up with blanks until the linesize is reached.
SET TRIMOUT ON --otherwise every line in the output is filled up with blanks until the linesize is reached.
spool Indicator_wise_comp_report.csv append;

SELECT 'Indicator_wise_comp_report.csv
----------------------------
' || SYSTIMESTAMP
FROM dual;


select  'COUNTRY_NAME ,COUNTRY_CODE ,INDICATOR_NAME, CURR_CALDENDAR_YEAR, LAST_YEAR, "LAST_YEAR-1" , "TREND" ' from dual;


select COUNTRY_NAME ||','||COUNTRY_CODE ||','||INDICATOR_NAME||','|| CURR_CALDENDAR_YEAR||','|| LAST_YEAR||','|| "LAST_YEAR-1" ||','|| TREND 
FROM (
SELECT COUNTRY_NAME ,COUNTRY_CODE ,INDICATOR_NAME, CURR_CALDENDAR_YEAR, LAST_YEAR, "LAST_YEAR-1" ,
    CASE WHEN TO_NUMBER(LAST_YEAR) < TO_NUMBER("LAST_YEAR-1") THEN 'UP'
         WHEN TO_NUMBER(LAST_YEAR) > TO_NUMBER("LAST_YEAR-1") THEN 'DOWN'
         ELSE 'NO CHANGE'
    END AS TREND
FROM (
select 
COUNTRY_NAME ,COUNTRY_CODE ,REPLACE(INDICATOR_NAME,',','-') INDICATOR_NAME ,year CURR_CALDENDAR_YEAR, year_data CURR_YEAR_DATA , 
LAG(year_data,1) OVER (partition by year order by year) LAST_YEAR  ,
LAG(year_data,2) OVER ( partition by year order by year) "LAST_YEAR-1"
from WDI_DATA_AGG_YR_AGG_YR
where 
INDICATOR_NAME ='Agriculture, forestry, and fishing, value added (% of GDP)'
--and country_code ='AFE' --
and year = '2020'
order by year desc
) 
);



 spool off;
