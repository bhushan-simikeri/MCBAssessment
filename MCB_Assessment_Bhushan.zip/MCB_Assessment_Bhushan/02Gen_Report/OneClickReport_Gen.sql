@00WDI_DATA_AGG_YR.data.sql
@01Country_wise_report.sql
@02Indicator_wise_chng_frm_prv_yr.sql
@03Indicator_wise_comp_report.sql